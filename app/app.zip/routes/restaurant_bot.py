# app/routes/restaurant_bot.py
from flask import Blueprint, Response, request
from flask_cors import CORS
from dotenv import load_dotenv
from app.extensions import db, limiter               # you already have these
from app.models import Restaurant, MenuItem, Layout  # for optional context
import os, json, openai, datetime as dt

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

restaurant_bot_bp = Blueprint("restaurant_bot", __name__, url_prefix="/api/restaurant-bot")
CORS(restaurant_bot_bp)           # CORS("...", supports_credentials=True) if you need cookies

SYSTEM_BASE = (
    "You are TableMate-AI, a helpful assistant for diners in Almaty.\n"
    "You can:\n"
    "• recommend restaurants from our DB;\n"
    "• suggest menu items that match dietary needs and price;\n"
    "• explain booking availability.\n"
    "If a question is NOT about restaurants, dining, or bookings you must politely refuse.\n"
)

FUNCTIONS = [{
    "name": "get_restaurant_info",
    "description": "Get details about a restaurant and its menu items",
    "parameters": {
        "type": "object",
        "properties": {
            "restaurant_name": {
                "type": "string",
                "description": "Name of the restaurant to look up"
            },
            "cuisine_type": {
                "type": "string",
                "description": "Type of cuisine (optional)"
            }
        },
        "required": ["restaurant_name"]
    }
}]

def get_restaurant_info(restaurant_name: str, cuisine_type: str = None):
    query = Restaurant.query
    if restaurant_name:
        query = query.filter(Restaurant.name.ilike(f"%{restaurant_name}%"))
    if cuisine_type:
        query = query.filter(Restaurant.cuisine.ilike(f"%{cuisine_type}%"))
    
    restaurant = query.first()
    if not restaurant:
        return {"error": "Restaurant not found"}
        
    menu_items = MenuItem.query.filter_by(restaurant_id=restaurant.id).limit(5).all()
    
    return {
        "restaurant": {
            "name": restaurant.name,
            "cuisine": restaurant.cuisine,
            "location": restaurant.location,
            "average_price": restaurant.average_price,
            "menu_items": [{
                "name": item.name,
                "price": item.price,
                "description": item.description,
                "category": item.category
            } for item in menu_items]
        }
    }

@restaurant_bot_bp.route("", methods=["POST", "OPTIONS"])
@limiter.limit("5/second")
def chat_stream():
    if request.method == "OPTIONS":
        return Response("", status=200)

    messages = request.json.get("messages", [])
    msg_chain = [{"role": "system", "content": SYSTEM_BASE}] + [
        m for m in messages if m["role"] != "system"
    ]

    def stream():
        resp = openai.chat.completions.create(
            model="gpt-4o-mini-2024-07-18",
            messages=msg_chain,
            functions=FUNCTIONS,
            stream=True,
            temperature=0.4,
            max_tokens=800,
        )
        
        function_call_data = ""
        for chunk in resp:
            delta = chunk.choices[0].delta
            
            # Handle function calls
            if delta.function_call:
                function_call_data += (delta.function_call.arguments or "")
                continue
                
            if function_call_data:
                # Execute function call
                try:
                    args = json.loads(function_call_data)
                    result = get_restaurant_info(**args)
                    # Add function result to message chain
                    msg_chain.append({
                        "role": "function",
                        "name": "get_restaurant_info",
                        "content": json.dumps(result)
                    })
                    # Get new completion with function result
                    inner_resp = openai.chat.completions.create(
                        model="gpt-4o-mini-2024-07-18",
                        messages=msg_chain,
                        stream=True,
                        temperature=0.4,
                        max_tokens=800,
                    )
                    for inner_chunk in inner_resp:
                        yield f"data:{inner_chunk.choices[0].delta.content or ''}\n\n"
                    return
                except Exception as e:
                    yield f"data:Sorry, I encountered an error: {str(e)}\n\n"
                    return
                
            yield f"data:{delta.content or ''}\n\n"

    return Response(stream(), mimetype="text/event-stream")
