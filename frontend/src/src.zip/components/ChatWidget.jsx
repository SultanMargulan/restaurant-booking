import React, { useState, useRef, useEffect } from "react";
import {
  FaRobot,
  FaPaperPlane,
  FaChevronDown,
  FaChevronUp,
} from "react-icons/fa";
import "../styles/ChatWidget.css";

/**
 * Floating chatbot widget for restaurant assistance.
 * - Collapsible/expandable
 * - Live streaming via SSE
 * - Bootstrap‑friendly + custom CSS (ChatWidget.css)
 */
const ChatWidget = () => {
  const [open, setOpen] = useState(true);
  const [history, setHistory] = useState([
    {
      role: "assistant",
      content: "Hi \uD83D\uDC4B — ask me anything about restaurants or menus!",
    },
  ]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const bodyRef = useRef(null);
  const sourceRef = useRef(null);

  // Auto‑scroll to newest message
  useEffect(() => {
    if (bodyRef.current) {
      bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
    }
  }, [history, open]);

  const closeStream = () => {
    if (sourceRef.current) {
      sourceRef.current.close();
      sourceRef.current = null;
    }
    setStreaming(false);
  };

  const send = () => {
    const text = input.trim();
    if (!text || streaming) return;

    const newHist = [...history, { role: "user", content: text }];
    setHistory(newHist);
    setInput("");
    setStreaming(true);

    // NOTE: EventSource does not support POST; fetch-event-source polyfill is an option.
    // For simplicity we use native fetch with ReadableStream (modern browsers).
    fetch("/api/restaurant-bot", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: newHist }),
    }).then(async (resp) => {
      if (!resp.ok || !resp.body) {
        throw new Error("Network error");
      }
      const reader = resp.body.getReader();
      let assistant = "";
      setHistory((h) => [...h, { role: "assistant", content: "" }]);
      const decode = new TextDecoder("utf-8");
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        assistant += decode.decode(value, { stream: true });
        setHistory((h) => [...h.slice(0, -1), { role: "assistant", content: assistant }]);
      }
    })
      .catch(() => {
        setHistory((h) => [
          ...h,
          { role: "assistant", content: "Sorry – something went wrong. Please try again." },
        ]);
      })
      .finally(() => setStreaming(false));
  };

  return (
    <div className="tm-chat">
      <div className="tm-chat__card">
        {/* Header */}
        <div className="tm-chat__header" onClick={() => setOpen(!open)}>
          <div className="tm-chat__header-title">
            <FaRobot /> TableMate‑AI
          </div>
          {open ? <FaChevronDown /> : <FaChevronUp />}
        </div>

        {/* Body */}
        {open && (
          <>
            <div className="tm-chat__body" ref={bodyRef}>
              {history.map((m, i) => (
                <div
                  key={i}
                  className={`tm-chat__message ${
                    m.role === 'user' ? 'tm-chat__message--user' : ''
                  }`}
                >
                  <div
                    className={`tm-chat__bubble ${
                      m.role === 'assistant'
                        ? 'tm-chat__bubble--assistant'
                        : 'tm-chat__bubble--user'
                    }`}
                  >
                    {m.content || <span className="tm-chat__typing">...</span>}
                  </div>
                </div>
              ))}
            </div>

            {/* Input */}
            <div className="tm-chat__input-container">
              <input
                type="text"
                className="tm-chat__input"
                placeholder="Type a message…"
                value={input}
                disabled={streaming}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && send()}
              />
              <button
                className="tm-chat__send-button"
                onClick={send}
                disabled={!input.trim() || streaming}
              >
                <FaPaperPlane />
                Send
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default ChatWidget;
